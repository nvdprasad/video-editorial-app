-- SQL for initializing the database
CREATE TABLE IF NOT EXISTS videos (
    id INTEGER PRIMARY KEY,
    title TEXT,
    filename TEXT,
    status TEXT,
    current_version INTEGER DEFAULT 1
);
