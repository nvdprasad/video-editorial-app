
# Video Editorial Workflow App

## Structure
- `backend/`: Node.js Express API
- `frontend/`: React + Tailwind UI
- `sql/`: SQL setup (uses SQLite by default)

## Deployment Instructions (Render.com)

### Backend
1. Deploy `backend/` as a Web Service
2. Start Command: `npm start`
3. Set Root Directory: `backend`
4. Add CORS if not already configured

### Frontend
1. Deploy `frontend/` as Static Site
2. Build Command: `npm install && npm run build`
3. Publish Directory: `frontend/build`
4. Set env variable: `REACT_APP_API_URL=https://<your-backend-url>.onrender.com`

## Development
```bash
cd backend
npm install
node index.js

cd frontend
npm install
npm start
```
