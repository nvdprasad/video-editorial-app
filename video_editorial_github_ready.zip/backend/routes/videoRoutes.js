const express = require('express');
const router = express.Router();
const { getVideos, uploadVideo, updateStatus } = require('../controllers/videoController');

router.get('/', getVideos);
router.post('/upload', uploadVideo);
router.patch('/status', updateStatus);

module.exports = router;
