const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

// Get all videos
const getVideos = (req, res) => {
    db.all('SELECT * FROM videos', (err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Database error' });
        }
        res.json(rows);
    });
};

// Upload a new video
const uploadVideo = (req, res) => {
    const { title, filename } = req.body;
    const status = 'Not Started';
    const query = 'INSERT INTO videos (title, filename, status) VALUES (?, ?, ?)';

    db.run(query, [title, filename, status], function(err) {
        if (err) {
            return res.status(500).json({ message: 'Database error' });
        }
        res.json({ message: 'Video uploaded successfully', videoId: this.lastID });
    });
};

// Update video status
const updateStatus = (req, res) => {
    const { videoId, status } = req.body;
    const query = 'UPDATE videos SET status = ? WHERE id = ?';

    db.run(query, [status, videoId], function(err) {
        if (err) {
            return res.status(500).json({ message: 'Database error' });
        }
        res.json({ message: 'Video status updated successfully' });
    });
};

module.exports = { getVideos, uploadVideo, updateStatus };
